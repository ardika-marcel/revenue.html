import { Navbar, Hero } from "@/components/HeroSection";
import ServicesSection from "@/components/ServicesSection";
import PricingSection from "@/components/PricingSection";
import QuoteForm from "@/components/QuoteForm";
import Footer from "@/components/Footer";

const Index = () => (
  <div className="min-h-screen bg-background font-body">
    <Navbar />
    <Hero />
    <ServicesSection />
    <PricingSection />
    <QuoteForm />
    <Footer />
  </div>
);

export default Index;
