import { motion } from "framer-motion";
import { Check, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const plans = [
  {
    label: "SERVICE 01",
    name: "Failed Payment Recovery",
    setup: "$1,500",
    rev: "5% of recovered revenue",
    features: [
      "Failed Payment Detection Engine",
      "Smart Retry Timing System",
      "AI Recovery Message Generator",
      "Automated Recovery Emails",
      "Revenue Recovery Dashboard",
      "Cancellation Insights Popup",
      "Card Expiry Reminder System",
    ],
    popular: true,
  },
  {
    label: "SERVICE 02",
    name: "Cart Abandonment Recovery",
    setup: "$1,000",
    rev: "5% of recovered revenue",
    features: [
      "Cart Abandonment Detection",
      "Automated Email Sequences",
      "Behavioral Analytics",
      "Cancellation Insights Popup",
      "Churn Pie Charts & Stats",
      "Multi-Step Recovery Flows",
    ],
    popular: false,
  },
];

const PricingSection = () => (
  <section id="pricing" className="py-24 bg-card">
    <div className="container">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-14"
      >
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-3">
          Simple, Transparent Pricing
        </h2>
        <p className="text-muted-foreground max-w-lg mx-auto">
          One-time setup fee + performance-based pricing. You only pay more when you earn more.
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {plans.map((plan, idx) => (
          <motion.div
            key={plan.name}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.15 }}
            className={`relative rounded-2xl p-8 bg-background border ${
              plan.popular ? "border-primary shadow-elevated" : "border-border shadow-card"
            }`}
          >
            {plan.popular && (
              <div className="absolute -top-3 left-8 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-semibold">
                Most Popular
              </div>
            )}
            <p className="text-xs font-semibold text-muted-foreground tracking-wider mb-2">{plan.label}</p>
            <h3 className="font-heading text-xl font-bold text-foreground mb-4">{plan.name}</h3>
            <div className="mb-6">
              <span className="font-heading text-4xl font-bold text-foreground">{plan.setup}</span>
              <span className="text-muted-foreground text-sm ml-2">setup fee</span>
              <p className="text-sm text-primary font-medium mt-1">+ {plan.rev}</p>
            </div>
            <ul className="space-y-3 mb-8">
              {plan.features.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm text-foreground">
                  <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
            <a href="#quote">
              <Button className="w-full gap-2" variant={plan.popular ? "default" : "outline"}>
                Get Started <ArrowRight className="w-4 h-4" />
              </Button>
            </a>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default PricingSection;
