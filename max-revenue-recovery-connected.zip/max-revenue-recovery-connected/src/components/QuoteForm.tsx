import { useState } from "react";
import { motion } from "framer-motion";
import { Send, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { supabase } from "@/lib/supabaseClient";

const QuoteForm = () => {
  const [form, setForm] = useState({ name: "", email: "", business: "", message: "" });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const { error } = await supabase.from("quote_requests").insert([
      {
        name: form.name,
        email: form.email,
        business: form.business,
        message: form.message,
      },
    ]);

    if (error) {
      console.error("Supabase error:", error);
      toast.error("Something went wrong. Please try again.");
    } else {
      toast.success("Quote request submitted! We'll be in touch within 24 hours.");
      setForm({ name: "", email: "", business: "", message: "" });
    }

    setIsSubmitting(false);
  };

  return (
    <section id="quote" className="py-24">
      <div className="container">
        <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
              Get Your Free Quote
            </h2>
            <p className="text-muted-foreground mb-8">
              Tell us about your business and we'll show you exactly how much revenue you're leaving on the table — and how we'll recover it.
            </p>
            <div className="p-6 rounded-xl bg-accent border border-border">
              <div className="flex items-center gap-3 mb-3">
                <Calendar className="w-5 h-5 text-primary" />
                <h4 className="font-heading font-semibold text-foreground">Prefer to talk?</h4>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Book a free 30-minute strategy call with our team.
              </p>
              <a href="https://calendar.google.com" target="_blank" rel="noopener noreferrer">
                <Button variant="outline" className="gap-2">
                  <Calendar className="w-4 h-4" /> Book a Call
                </Button>
              </a>
            </div>
          </motion.div>

          <motion.form
            onSubmit={handleSubmit}
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-5 p-8 rounded-2xl bg-card border border-border shadow-card"
          >
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Full Name</label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="John Doe"
                required
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Email</label>
              <Input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="john@company.com"
                required
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Business Name & URL</label>
              <Input
                value={form.business}
                onChange={(e) => setForm({ ...form, business: e.target.value })}
                placeholder="Acme Inc — acme.com"
                required
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Tell us about your needs</label>
              <Textarea
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                placeholder="Monthly revenue, payment processor, current churn rate…"
                rows={4}
              />
            </div>
            <Button type="submit" className="w-full gap-2" disabled={isSubmitting}>
              <Send className="w-4 h-4" />
              {isSubmitting ? "Submitting…" : "Request Free Quote"}
            </Button>
          </motion.form>
        </div>
      </div>
    </section>
  );
};

export default QuoteForm;
