import { motion } from "framer-motion";
import {
  CreditCard, Mail, BarChart3, PieChart, Bell, Brain,
  ShoppingCart, Send, TrendingDown, Eye
} from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.1, duration: 0.5 },
  }),
};

const service1Features = [
  { icon: CreditCard, title: "Failed Payment Detection Engine", desc: "Smart retry timing that detects expired cards, insufficient funds, and processor errors automatically." },
  { icon: Brain, title: "AI Recovery Message Generator", desc: "LLM-powered follow-up emails tailored to each failure reason — expired card, insufficient funds, or network issues." },
  { icon: BarChart3, title: "Revenue Recovery Dashboard", desc: "Visual revenue insights with real-time tracking of recovered payments and retry success rates." },
  { icon: PieChart, title: "Cancellation Insights Popup", desc: "Understand churn reasons with interactive pie charts and actionable insights." },
  { icon: Bell, title: "Card Expiry Reminder System", desc: "Proactively notify customers before their card expires to prevent failures." },
];

const service2Features = [
  { icon: ShoppingCart, title: "Cart Abandonment Detection", desc: "Track when customers leave items in their cart and trigger recovery workflows." },
  { icon: Send, title: "Automated Email Sequences", desc: "Multi-step email campaigns personalized by cart contents, customer behavior, and timing." },
  { icon: TrendingDown, title: "Cancellation Insights Popup", desc: "Understand churn reasons with statistics, pie charts, and actionable insights." },
  { icon: Eye, title: "Behavioral Analytics", desc: "Deep analysis of abandonment patterns to optimize your checkout flow." },
];

const ServiceCard = ({ icon: Icon, title, desc, i }: { icon: React.ElementType; title: string; desc: string; i: number }) => (
  <motion.div
    custom={i}
    variants={fadeUp}
    initial="hidden"
    whileInView="visible"
    viewport={{ once: true }}
    className="p-6 rounded-xl bg-background shadow-card border border-border hover:shadow-elevated transition-shadow"
  >
    <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center mb-4">
      <Icon className="w-5 h-5 text-primary" />
    </div>
    <h4 className="font-heading font-semibold text-foreground mb-2">{title}</h4>
    <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
  </motion.div>
);

const ServicesSection = () => (
  <section id="services" className="py-24">
    <div className="container">
      {/* Service 1 */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="mb-20"
      >
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent text-accent-foreground text-xs font-semibold mb-3">
          SERVICE 01
        </div>
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-3">
          Failed Payment Recovery
        </h2>
        <p className="text-muted-foreground max-w-2xl mb-10">
          AI-powered system that detects failed payments, identifies the cause, and sends personalized recovery emails — recovering revenue you'd otherwise lose.
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {service1Features.map((f, i) => (
            <ServiceCard key={f.title} {...f} i={i} />
          ))}
        </div>
      </motion.div>

      {/* Service 2 */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent text-accent-foreground text-xs font-semibold mb-3">
          SERVICE 02
        </div>
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-3">
          E-Commerce Cart Recovery
        </h2>
        <p className="text-muted-foreground max-w-2xl mb-10">
          Automated email marketing that brings customers back to complete their purchase — with cancellation insights to reduce future churn.
        </p>
        <div className="grid md:grid-cols-2 gap-5">
          {service2Features.map((f, i) => (
            <ServiceCard key={f.title} {...f} i={i} />
          ))}
        </div>
      </motion.div>
    </div>
  </section>
);

export default ServicesSection;
