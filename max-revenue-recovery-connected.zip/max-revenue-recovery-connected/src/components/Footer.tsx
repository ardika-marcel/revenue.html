const Footer = () => (
  <footer className="py-12 border-t border-border bg-card">
    <div className="container">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="font-heading text-lg font-bold text-foreground">
          Max<span className="text-primary">Revenue</span>
        </p>
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} Max Revenue. All rights reserved.
        </p>
      </div>
    </div>
  </footer>
);

export default Footer;
