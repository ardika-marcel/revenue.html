import { motion } from "framer-motion";
import { ArrowRight, Shield, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

const Navbar = () => (
  <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
    <div className="container flex items-center justify-between h-16">
      <a href="#" className="font-heading text-xl font-bold text-foreground">
        Max<span className="text-primary">Revenue</span>
      </a>
      <div className="hidden md:flex items-center gap-8">
        <a href="#services" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Services</a>
        <a href="#pricing" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Pricing</a>
        <a href="#quote" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Get Quote</a>
      </div>
      <a href="https://calendar.google.com" target="_blank" rel="noopener noreferrer">
        <Button size="sm">Book a Call</Button>
      </a>
    </div>
  </nav>
);

const Hero = () => (
  <section className="relative pt-32 pb-20 overflow-hidden" style={{ background: "var(--gradient-hero)" }}>
    <div className="container relative z-10">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="max-w-3xl mx-auto text-center"
      >
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-accent text-accent-foreground text-sm font-medium mb-6">
          <TrendingUp className="w-4 h-4" />
          Revenue Recovery & Growth
        </div>
        <h1 className="font-heading text-4xl md:text-6xl font-bold text-foreground leading-tight mb-6">
          Stop Losing Revenue.
          <br />
          <span className="text-primary">Start Recovering It.</span>
        </h1>
        <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
          We help SaaS and e-commerce businesses recover failed payments, reduce churn, and recapture abandoned carts — all on autopilot.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a href="#quote">
            <Button size="lg" className="gap-2">
              Get a Free Quote <ArrowRight className="w-4 h-4" />
            </Button>
          </a>
          <a href="#services">
            <Button variant="outline" size="lg" className="gap-2">
              <Shield className="w-4 h-4" /> See How It Works
            </Button>
          </a>
        </div>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.3 }}
        className="mt-16 grid grid-cols-3 gap-6 max-w-2xl mx-auto"
      >
        {[
          { stat: "$2.4M+", label: "Revenue Recovered" },
          { stat: "38%", label: "Avg Recovery Rate" },
          { stat: "150+", label: "Businesses Served" },
        ].map((item) => (
          <div key={item.label} className="text-center p-4 rounded-xl bg-background shadow-card">
            <p className="font-heading text-2xl font-bold text-primary">{item.stat}</p>
            <p className="text-sm text-muted-foreground mt-1">{item.label}</p>
          </div>
        ))}
      </motion.div>
    </div>
  </section>
);

export { Navbar, Hero };
